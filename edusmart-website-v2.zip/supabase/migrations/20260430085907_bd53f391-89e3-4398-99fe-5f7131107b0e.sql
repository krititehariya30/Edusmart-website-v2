-- Track student quiz/assignment attempts so performance reflects real activity
CREATE TABLE IF NOT EXISTS public.quiz_attempts (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  topic text NOT NULL,
  difficulty text NOT NULL DEFAULT 'medium',
  total_questions integer NOT NULL,
  correct_answers integer NOT NULL,
  score_percent numeric NOT NULL,
  kind text NOT NULL DEFAULT 'quiz', -- 'quiz' | 'assignment'
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.quiz_attempts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users insert own attempts"
ON public.quiz_attempts FOR INSERT TO authenticated
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users view own attempts"
ON public.quiz_attempts FOR SELECT TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Teachers and admins view all attempts"
ON public.quiz_attempts FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'teacher') OR public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS idx_quiz_attempts_user ON public.quiz_attempts(user_id, created_at DESC);
