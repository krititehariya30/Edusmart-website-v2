
-- Subjects
CREATE TABLE public.subjects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Students
CREATE TABLE public.students (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  grade text NOT NULL DEFAULT '10',
  parent_email text NOT NULL,
  teacher_email text NOT NULL,
  avatar_color text NOT NULL DEFAULT '#7c6ef7',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Scores
CREATE TABLE public.scores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid NOT NULL REFERENCES public.students(id) ON DELETE CASCADE,
  subject_id uuid NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  score numeric NOT NULL CHECK (score >= 0 AND score <= 100),
  test_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX scores_student_idx ON public.scores(student_id, test_date DESC);

-- Notifications
CREATE TABLE public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  student_id uuid REFERENCES public.students(id) ON DELETE CASCADE,
  recipient_role text NOT NULL CHECK (recipient_role IN ('parent','teacher')),
  recipient_email text NOT NULL,
  title text NOT NULL,
  message text NOT NULL,
  severity text NOT NULL DEFAULT 'warning' CHECK (severity IN ('info','warning','critical')),
  read boolean NOT NULL DEFAULT false,
  email_sent boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_recent_idx ON public.notifications(created_at DESC);

-- RLS - public demo (no auth)
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.students ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public read subjects" ON public.subjects FOR SELECT USING (true);
CREATE POLICY "public write subjects" ON public.subjects FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "public read students" ON public.students FOR SELECT USING (true);
CREATE POLICY "public write students" ON public.students FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "public read scores" ON public.scores FOR SELECT USING (true);
CREATE POLICY "public write scores" ON public.scores FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "public read notifications" ON public.notifications FOR SELECT USING (true);
CREATE POLICY "public write notifications" ON public.notifications FOR ALL USING (true) WITH CHECK (true);
