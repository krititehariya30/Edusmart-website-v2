-- Roles enum
create type public.app_role as enum ('student','teacher','parent','admin');

-- Profiles
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text not null default '',
  phone text,
  parent_email text,
  parent_phone text,
  teacher_email text,
  teacher_phone text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;

create policy "profiles readable by authenticated"
on public.profiles for select to authenticated using (true);

create policy "users update own profile"
on public.profiles for update to authenticated
using (auth.uid() = id) with check (auth.uid() = id);

create policy "users insert own profile"
on public.profiles for insert to authenticated
with check (auth.uid() = id);

-- User roles
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

-- Security definer role-check
create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.user_roles where user_id=_user_id and role=_role)
$$;

create policy "roles readable by authenticated"
on public.user_roles for select to authenticated using (true);

create policy "admins manage roles"
on public.user_roles for all to authenticated
using (public.has_role(auth.uid(),'admin'))
with check (public.has_role(auth.uid(),'admin'));

create policy "users insert own role on signup"
on public.user_roles for insert to authenticated
with check (auth.uid() = user_id);

-- updated_at trigger
create or replace function public.tg_set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

create trigger profiles_set_updated_at
before update on public.profiles
for each row execute function public.tg_set_updated_at();

-- Auto profile + role from signup metadata
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
declare
  v_role public.app_role;
begin
  insert into public.profiles (id, name, phone, parent_email, parent_phone, teacher_email, teacher_phone)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name',''),
    new.raw_user_meta_data->>'phone',
    new.raw_user_meta_data->>'parent_email',
    new.raw_user_meta_data->>'parent_phone',
    new.raw_user_meta_data->>'teacher_email',
    new.raw_user_meta_data->>'teacher_phone'
  );

  begin
    v_role := coalesce((new.raw_user_meta_data->>'role')::public.app_role, 'student'::public.app_role);
  exception when others then
    v_role := 'student';
  end;

  insert into public.user_roles (user_id, role) values (new.id, v_role)
  on conflict do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();