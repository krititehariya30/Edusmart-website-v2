// Performance drop detector.
// For a given student (or all students), compares the last score in each subject
// vs the average of the previous 3 scores. If it dropped >= 8 points, creates
// notifications for parent + teacher and (optionally) sends emails.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const DROP_THRESHOLD = 8;

interface Drop {
  subject: string;
  previousAvg: number;
  latest: number;
  delta: number;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = req.method === "POST" ? await req.json().catch(() => ({})) : {};
    const studentId: string | undefined = body.studentId;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: students, error: sErr } = await supabase
      .from("students")
      .select("id, name, parent_email, teacher_email")
      .filter("id", studentId ? "eq" : "not.is", studentId ?? null);
    if (sErr) throw sErr;

    const { data: subjects } = await supabase.from("subjects").select("id, name");
    const subjMap = new Map((subjects ?? []).map((s: any) => [s.id, s.name]));

    const created: any[] = [];

    for (const student of students ?? []) {
      const { data: scores } = await supabase
        .from("scores")
        .select("subject_id, score, test_date")
        .eq("student_id", student.id)
        .order("test_date", { ascending: false });

      // group by subject (already desc)
      const bySubject = new Map<string, { score: number; date: string }[]>();
      for (const r of scores ?? []) {
        const arr = bySubject.get(r.subject_id) ?? [];
        arr.push({ score: Number(r.score), date: r.test_date });
        bySubject.set(r.subject_id, arr);
      }

      const drops: Drop[] = [];
      for (const [subjectId, arr] of bySubject) {
        if (arr.length < 4) continue;
        const latest = arr[0].score;
        const prev3 = arr.slice(1, 4).map((x) => x.score);
        const prevAvg = prev3.reduce((a, b) => a + b, 0) / prev3.length;
        if (prevAvg - latest >= DROP_THRESHOLD) {
          drops.push({
            subject: subjMap.get(subjectId) ?? "Unknown",
            previousAvg: Number(prevAvg.toFixed(1)),
            latest,
            delta: Number((prevAvg - latest).toFixed(1)),
          });
        }
      }

      if (drops.length === 0) continue;

      const subjectsList = drops.map((d) => `${d.subject} (−${d.delta} pts)`).join(", ");
      const severity = drops.some((d) => d.delta >= 15) ? "critical" : "warning";
      const title = `Performance drop alert for ${student.name}`;
      const message =
        `${student.name}'s recent scores show a notable drop in: ${subjectsList}. ` +
        `Consider scheduling a check-in and review of recent topics. ` +
        drops
          .map((d) => `• ${d.subject}: latest ${d.latest} vs prior avg ${d.previousAvg}`)
          .join("\n");

      for (const role of ["parent", "teacher"] as const) {
        const email = role === "parent" ? student.parent_email : student.teacher_email;
        const { data: ins, error: iErr } = await supabase
          .from("notifications")
          .insert({
            student_id: student.id,
            recipient_role: role,
            recipient_email: email,
            title,
            message,
            severity,
          })
          .select()
          .single();
        if (iErr) {
          console.error("notif insert err", iErr);
          continue;
        }
        created.push(ins);

        // Try to send email via Resend if connector is connected
        try {
          await sendEmail(email, title, message, student.name, drops);
          await supabase.from("notifications").update({ email_sent: true }).eq("id", ins.id);
        } catch (e) {
          console.warn("email send skipped/failed:", (e as Error).message);
        }
      }
    }

    return new Response(JSON.stringify({ ok: true, created: created.length }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("check-performance error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function sendEmail(to: string, subject: string, text: string, studentName: string, drops: Drop[]) {
  const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
  if (!LOVABLE_API_KEY || !RESEND_API_KEY) {
    throw new Error("Email connector (Resend) not configured — alert created in-site only");
  }

  const rows = drops
    .map(
      (d) =>
        `<tr><td style="padding:8px;border-bottom:1px solid #eee">${d.subject}</td>` +
        `<td style="padding:8px;border-bottom:1px solid #eee">${d.previousAvg}</td>` +
        `<td style="padding:8px;border-bottom:1px solid #eee;color:#c00">${d.latest}</td>` +
        `<td style="padding:8px;border-bottom:1px solid #eee;color:#c00">−${d.delta}</td></tr>`,
    )
    .join("");

  const html = `
    <div style="font-family:system-ui,sans-serif;max-width:560px;margin:auto;padding:24px;background:#fff">
      <h2 style="color:#7c6ef7;margin:0 0 8px">Performance Alert</h2>
      <p style="color:#333">A notable drop has been detected for <strong>${studentName}</strong>.</p>
      <table style="width:100%;border-collapse:collapse;margin:16px 0;font-size:14px">
        <thead><tr style="background:#f5f5fa">
          <th style="text-align:left;padding:8px">Subject</th>
          <th style="text-align:left;padding:8px">Prior Avg</th>
          <th style="text-align:left;padding:8px">Latest</th>
          <th style="text-align:left;padding:8px">Drop</th>
        </tr></thead><tbody>${rows}</tbody>
      </table>
      <p style="color:#666;font-size:13px">This is an automated notification from your Smart Education Assistant.</p>
    </div>`;

  const r = await fetch("https://connector-gateway.lovable.dev/resend/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${LOVABLE_API_KEY}`,
      "X-Connection-Api-Key": RESEND_API_KEY,
    },
    body: JSON.stringify({
      from: "Smart Edu Alerts <onboarding@resend.dev>",
      to: [to],
      subject,
      html,
      text,
    }),
  });
  if (!r.ok) throw new Error(`Resend ${r.status}: ${await r.text()}`);
}
