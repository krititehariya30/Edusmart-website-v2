// Interest analysis — uses Lovable AI to interpret a student's strongest subjects
// and recommend learning paths / careers tailored to those strengths.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { studentId } = await req.json();
    if (!studentId) {
      return new Response(JSON.stringify({ error: "studentId required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY missing");

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: student } = await supabase
      .from("students")
      .select("name, grade")
      .eq("id", studentId)
      .single();
    const { data: scores } = await supabase
      .from("scores")
      .select("score, test_date, subjects(name)")
      .eq("student_id", studentId);

    const bySubject: Record<string, number[]> = {};
    for (const r of scores ?? []) {
      const n = (r as any).subjects?.name;
      if (!n) continue;
      (bySubject[n] ||= []).push(Number(r.score));
    }
    const stats = Object.entries(bySubject).map(([subject, arr]) => {
      const avg = arr.reduce((a, b) => a + b, 0) / arr.length;
      // simple trend: avg of newest half - avg of oldest half
      const sorted = [...arr];
      const half = Math.floor(sorted.length / 2);
      const oldHalf = sorted.slice(0, half);
      const newHalf = sorted.slice(half);
      const trend =
        newHalf.reduce((a, b) => a + b, 0) / Math.max(newHalf.length, 1) -
        oldHalf.reduce((a, b) => a + b, 0) / Math.max(oldHalf.length, 1);
      return { subject, average: Number(avg.toFixed(1)), trend: Number(trend.toFixed(1)) };
    });

    stats.sort((a, b) => b.average - a.average);
    const strengths = stats.slice(0, 3);

    const prompt =
      `Student: ${student?.name} (Grade ${student?.grade}).\n` +
      `Subject performance:\n` +
      stats.map((s) => `- ${s.subject}: avg ${s.average}, trend ${s.trend > 0 ? "+" : ""}${s.trend}`).join("\n") +
      `\n\nBased on the student's strongest and improving subjects, identify:\n` +
      `1. Their likely interest areas\n` +
      `2. 4 personalized learning path suggestions (specific topics to explore)\n` +
      `3. 4 potential career directions that match\n` +
      `4. One concrete next-step project idea`;

    const r = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content:
              "You are an academic advisor. Output well-structured Markdown with clear section headings (##) and bullet points. Be specific and encouraging.",
          },
          { role: "user", content: prompt },
        ],
      }),
    });

    if (!r.ok) {
      if (r.status === 429)
        return new Response(JSON.stringify({ error: "Rate limit, try again." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      if (r.status === 402)
        return new Response(JSON.stringify({ error: "AI credits exhausted." }), {
          status: 402,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      throw new Error(`gateway ${r.status}`);
    }
    const j = await r.json();
    const analysis = j.choices?.[0]?.message?.content ?? "";

    return new Response(JSON.stringify({ stats, strengths, analysis }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("interest-analysis", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
