// AI Tutor — streaming chat backed by Lovable AI Gateway
// Uses student's recent scores to personalize responses.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const { messages, studentId } = await req.json();
    if (!Array.isArray(messages)) {
      return new Response(JSON.stringify({ error: "messages array required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Build personalized system prompt from student data
    let context = "";
    if (studentId) {
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      );
      const { data: student } = await supabase
        .from("students")
        .select("name, grade")
        .eq("id", studentId)
        .maybeSingle();
      const { data: scores } = await supabase
        .from("scores")
        .select("score, test_date, subjects(name)")
        .eq("student_id", studentId)
        .order("test_date", { ascending: false })
        .limit(30);

      if (student) {
        const bySubject: Record<string, number[]> = {};
        for (const r of scores ?? []) {
          const name = (r as any).subjects?.name;
          if (!name) continue;
          (bySubject[name] ||= []).push(Number(r.score));
        }
        const summary = Object.entries(bySubject)
          .map(([n, arr]) => `${n}: avg ${(arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1)}`)
          .join("; ");
        context = `\n\nStudent context — Name: ${student.name}, Grade: ${student.grade}. Recent averages — ${summary}. Tailor explanations to their level and reference their stronger subjects when helpful.`;
      }
    }

    const systemPrompt =
      "You are an expert AI tutor for school students. Give clear, accurate, step-by-step explanations. Use simple language, examples, and short paragraphs. When math is involved, show working. Never refuse to answer a legitimate study question." +
      context;

    const upstream = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        stream: true,
        messages: [{ role: "system", content: systemPrompt }, ...messages],
      }),
    });

    if (!upstream.ok) {
      if (upstream.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please try again shortly." }), {
          status: 429,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (upstream.status === 402) {
        return new Response(
          JSON.stringify({ error: "AI credits exhausted. Add funds in Lovable workspace settings." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
      const text = await upstream.text();
      console.error("AI gateway error", upstream.status, text);
      return new Response(JSON.stringify({ error: "AI gateway error" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(upstream.body, {
      headers: { ...corsHeaders, "Content-Type": "text/event-stream" },
    });
  } catch (e) {
    console.error("ai-tutor error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
