export interface Student {
  id: string;
  name: string;
  grade: string;
  parent_email: string;
  teacher_email: string;
  avatar_color: string;
}
export interface Subject { id: string; name: string }
export interface ScoreRow {
  id: string;
  student_id: string;
  subject_id: string;
  score: number;
  test_date: string;
}
export interface NotificationRow {
  id: string;
  student_id: string | null;
  recipient_role: "parent" | "teacher";
  recipient_email: string;
  title: string;
  message: string;
  severity: "info" | "warning" | "critical";
  read: boolean;
  email_sent: boolean;
  created_at: string;
}
