import { Student } from "@/lib/types";

interface Props {
  students: Student[];
  selectedId: string | null;
  onSelect: (id: string) => void;
}

export const StudentPicker = ({ students, selectedId, onSelect }: Props) => (
  <div className="flex flex-wrap gap-2">
    {students.map((s) => {
      const active = s.id === selectedId;
      return (
        <button
          key={s.id}
          onClick={() => onSelect(s.id)}
          className={`flex items-center gap-2 rounded-xl border px-3 py-2 text-sm transition-all ${
            active
              ? "border-primary bg-primary/10 text-foreground"
              : "border-border bg-secondary/40 text-muted-foreground hover:text-foreground"
          }`}
        >
          <span
            className="grid h-7 w-7 place-items-center rounded-full text-xs font-semibold text-primary-foreground"
            style={{ background: s.avatar_color }}
          >
            {s.name.split(" ").map((p) => p[0]).join("").slice(0, 2)}
          </span>
          <span>{s.name}</span>
          <span className="text-xs text-muted-foreground">G{s.grade}</span>
        </button>
      );
    })}
  </div>
);
