import { Link, useLocation } from "react-router-dom";
import { Sparkles } from "lucide-react";

export const FloatingAI = () => {
  const { pathname } = useLocation();
  if (pathname.startsWith("/tutor") || pathname === "/login" || pathname === "/signup" || pathname === "/")
    return null;
  return (
    <Link to="/tutor"
      className="fixed bottom-6 right-6 z-40 grid h-14 w-14 place-items-center rounded-full text-primary-foreground shadow-2xl transition-transform hover:scale-110 animate-fade-in"
      style={{ background: "var(--gradient-brand)", boxShadow: "var(--shadow-glow)" }}
      aria-label="Open AI Tutor">
      <Sparkles className="h-6 w-6" />
    </Link>
  );
};
