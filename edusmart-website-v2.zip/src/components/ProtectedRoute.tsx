import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth, AppRole, roleHome } from "@/lib/auth";
import { Loader2 } from "lucide-react";

export const ProtectedRoute = ({ children, roles }: { children: ReactNode; roles?: AppRole[] }) => {
  const { user, loading, roles: userRoles, primaryRole } = useAuth();
  if (loading) {
    return (
      <div className="grid min-h-screen place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary" />
      </div>
    );
  }
  if (!user) return <Navigate to="/login" replace />;
  if (roles && !roles.some((r) => userRoles.includes(r))) {
    return <Navigate to={roleHome(primaryRole)} replace />;
  }
  return <>{children}</>;
};
