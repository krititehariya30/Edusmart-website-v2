import { NavLink, Link } from "react-router-dom";
import { GraduationCap, LayoutDashboard, MessageSquare, Bell, Sparkles, BookOpen, FileText, LogOut, Users } from "lucide-react";
import { useAuth, roleHome } from "@/lib/auth";
import { ThemeToggle } from "./ThemeToggle";

export const Navbar = () => {
  const { user, primaryRole, profile, signOut } = useAuth();
  const links = [
    { to: roleHome(primaryRole), label: "Home", icon: LayoutDashboard, roles: ["student","teacher","parent","admin"] as const },
    { to: "/tutor", label: "AI Tutor", icon: MessageSquare, roles: ["student","teacher","parent","admin"] as const },
    { to: "/quiz", label: "Quiz", icon: BookOpen, roles: ["student","teacher"] as const },
    { to: "/notes", label: "Notes", icon: FileText, roles: ["student","teacher"] as const },
    { to: "/dashboard", label: "Analytics", icon: LayoutDashboard, roles: ["teacher","admin","parent"] as const },
    { to: "/interest", label: "Interests", icon: Sparkles, roles: ["student","teacher","parent","admin"] as const },
    { to: "/notifications", label: "Alerts", icon: Bell, roles: ["teacher","parent","admin"] as const },
    { to: "/admin", label: "Admin", icon: Users, roles: ["admin"] as const },
  ].filter((l) => !primaryRole || (l.roles as readonly string[]).includes(primaryRole));

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between gap-3 px-6">
        <Link to={user ? roleHome(primaryRole) : "/"} className="flex items-center gap-2">
          <div className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-base font-semibold gradient-text">EduSmart</span>
        </Link>
        <nav className="hidden md:flex items-center gap-1 overflow-x-auto">
          {user && links.map(({ to, label, icon: Icon }) => (
            <NavLink key={to+label} to={to}
              className={({ isActive }) =>
                `flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                  isActive ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/60"
                }`}>
              <Icon className="h-4 w-4" /><span className="hidden lg:inline">{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          {user ? (
            <>
              <span className="hidden sm:block text-xs text-muted-foreground">
                {profile?.name || user.email} · <span className="text-primary capitalize">{primaryRole}</span>
              </span>
              <button onClick={signOut} className="grid h-9 w-9 place-items-center rounded-lg border border-border hover:bg-secondary" aria-label="Sign out">
                <LogOut className="h-4 w-4" />
              </button>
            </>
          ) : (
            <Link to="/login" className="btn-brand text-sm">Sign in</Link>
          )}
        </div>
      </div>
    </header>
  );
};
