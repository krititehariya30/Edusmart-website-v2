import { Link } from "react-router-dom";
import { Navbar } from "@/components/Navbar";
import { Sparkles, Brain, Bell, BookOpen, ArrowRight, GraduationCap, Users, ShieldCheck } from "lucide-react";

const Landing = () => (
  <div className="min-h-screen">
    <Navbar />
    <main>
      <section className="mx-auto max-w-7xl px-6 pt-16 pb-20 text-center">
        <div className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/50 px-4 py-1.5 text-xs text-muted-foreground animate-fade-in">
          <Sparkles className="h-3 w-3 text-primary" /> AI-powered learning, monitoring & alerts
        </div>
        <h1 className="mt-6 text-5xl md:text-7xl font-bold tracking-tight animate-fade-in">
          Smarter learning with <span className="gradient-text">EduSmart</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground animate-fade-in">
          A unified platform for students, teachers and parents — AI tutoring, instant quizzes,
          smart notes, and automated alerts when performance drops.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3 animate-fade-in">
          <Link to="/signup" className="btn-brand inline-flex items-center gap-2">
            Get started <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/login" className="rounded-lg border border-border px-5 py-2 text-sm hover:bg-secondary">
            I already have an account
          </Link>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 pb-16 grid gap-4 md:grid-cols-3">
        {[
          { icon: Brain, title: "AI Tutor", text: "Context-aware tutoring personalized to each student's recent performance." },
          { icon: BookOpen, title: "AI Quizzes & Notes", text: "Generate quizzes and study notes from any topic in seconds." },
          { icon: Bell, title: "Smart Alerts", text: "Parents and teachers are notified the moment performance drops." },
          { icon: GraduationCap, title: "Role dashboards", text: "Tailored views for students, teachers, parents and admins." },
          { icon: Users, title: "Performance analytics", text: "Trends, weak areas, and strong areas at a glance." },
          { icon: ShieldCheck, title: "Secure by default", text: "Row-level security and role-based access on every endpoint." },
        ].map((f, i) => (
          <div key={i} className="glass p-6 animate-fade-in">
            <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
              <f.icon className="h-5 w-5 text-primary-foreground" />
            </div>
            <h3 className="mt-4 text-lg font-semibold">{f.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
          </div>
        ))}
      </section>
    </main>
  </div>
);

export default Landing;
