import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { NotificationRow, Student } from "@/lib/types";
import { Bell, AlertTriangle, AlertOctagon, Info, Mail, MailX, Loader2 } from "lucide-react";
import { toast } from "sonner";

const Notifications = () => {
  const [items, setItems] = useState<NotificationRow[]>([]);
  const [students, setStudents] = useState<Record<string, Student>>({});
  const [filter, setFilter] = useState<"all" | "parent" | "teacher">("all");
  const [scanning, setScanning] = useState(false);

  const load = async () => {
    const [{ data: notifs }, { data: studs }] = await Promise.all([
      supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("students").select("*"),
    ]);
    setItems((notifs as NotificationRow[]) ?? []);
    const map: Record<string, Student> = {};
    for (const s of (studs as Student[]) ?? []) map[s.id] = s;
    setStudents(map);
  };

  useEffect(() => { load(); }, []);

  const scan = async () => {
    setScanning(true);
    try {
      const { data, error } = await supabase.functions.invoke("check-performance", { body: {} });
      if (error) throw error;
      toast.success(`Scan complete — ${data?.created ?? 0} alerts`);
      await load();
    } catch {
      toast.error("Scan failed");
    } finally {
      setScanning(false);
    }
  };

  const markRead = async (id: string) => {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    setItems((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const filtered = items.filter((i) => filter === "all" || i.recipient_role === filter);

  const sevIcon = (s: NotificationRow["severity"]) =>
    s === "critical" ? <AlertOctagon className="h-4 w-4 text-[hsl(var(--destructive))]" />
    : s === "warning" ? <AlertTriangle className="h-4 w-4 text-[hsl(var(--warning))]" />
    : <Info className="h-4 w-4 text-accent" />;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-4xl space-y-6 px-6 py-8">
        <header className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold flex items-center gap-2"><Bell className="h-6 w-6" /> Notifications</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Performance-drop alerts sent to parents and teachers.
            </p>
          </div>
          <button onClick={scan} disabled={scanning} className="btn-brand inline-flex items-center gap-2">
            {scanning ? <Loader2 className="h-4 w-4 animate-spin" /> : <AlertTriangle className="h-4 w-4" />}
            Run scan now
          </button>
        </header>

        <div className="flex gap-2">
          {(["all", "parent", "teacher"] as const).map((k) => (
            <button
              key={k}
              onClick={() => setFilter(k)}
              className={`rounded-lg px-3 py-1.5 text-sm capitalize ${
                filter === k ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"
              }`}
            >
              {k}
            </button>
          ))}
        </div>

        <section className="space-y-3">
          {filtered.length === 0 && (
            <div className="glass p-10 text-center text-sm text-muted-foreground">
              No notifications yet. Run a scan to detect performance drops.
            </div>
          )}
          {filtered.map((n) => {
            const stu = n.student_id ? students[n.student_id] : null;
            return (
              <article
                key={n.id}
                className={`glass p-5 ${!n.read ? "ring-1 ring-primary/40" : ""}`}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    {sevIcon(n.severity)}
                    <div>
                      <h3 className="font-semibold">{n.title}</h3>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        To {n.recipient_role}: <span className="text-foreground">{n.recipient_email}</span>
                        {stu && <> • Student: <span className="text-foreground">{stu.name}</span></>}
                        {" • "}{new Date(n.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <span
                    className="inline-flex items-center gap-1 rounded-full border border-border px-2 py-0.5 text-xs text-muted-foreground"
                    title={n.email_sent ? "Email delivered" : "Email not sent (in-site only)"}
                  >
                    {n.email_sent ? <Mail className="h-3 w-3" /> : <MailX className="h-3 w-3" />}
                    {n.email_sent ? "Emailed" : "In-site only"}
                  </span>
                </div>
                <p className="mt-3 whitespace-pre-line text-sm text-foreground/90">{n.message}</p>
                {!n.read && (
                  <button onClick={() => markRead(n.id)} className="mt-3 text-xs text-primary hover:underline">
                    Mark as read
                  </button>
                )}
              </article>
            );
          })}
        </section>
      </main>
    </div>
  );
};

export default Notifications;
