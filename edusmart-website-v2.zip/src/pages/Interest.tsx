import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { StudentPicker } from "@/components/StudentPicker";
import { supabase } from "@/integrations/supabase/client";
import { Student } from "@/lib/types";
import ReactMarkdown from "react-markdown";
import { Sparkles, Loader2, Award } from "lucide-react";
import { toast } from "sonner";

interface Result {
  stats: { subject: string; average: number; trend: number }[];
  strengths: { subject: string; average: number; trend: number }[];
  analysis: string;
}

const Interest = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [studentId, setStudentId] = useState<string | null>(null);
  const [data, setData] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    supabase.from("students").select("*").order("name").then(({ data }) => {
      setStudents((data as Student[]) ?? []);
      if (data && data.length) setStudentId(data[0].id);
    });
  }, []);

  const analyze = async () => {
    if (!studentId) return;
    setLoading(true);
    setData(null);
    try {
      const { data, error } = await supabase.functions.invoke("interest-analysis", {
        body: { studentId },
      });
      if (error) throw error;
      setData(data as Result);
    } catch (e) {
      toast.error("Analysis failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-5xl space-y-6 px-6 py-8">
        <header>
          <h1 className="text-2xl font-semibold">Interest & Strength Analysis</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            AI identifies the student's strongest subjects and suggests learning paths and careers that match.
          </p>
        </header>

        <section className="glass p-5">
          <StudentPicker students={students} selectedId={studentId} onSelect={(id) => { setStudentId(id); setData(null); }} />
          <button onClick={analyze} disabled={loading || !studentId} className="btn-brand mt-4 inline-flex items-center gap-2 disabled:opacity-50">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            Analyze interests
          </button>
        </section>

        {data && (
          <>
            <section className="grid gap-4 md:grid-cols-3">
              {data.strengths.map((s) => (
                <div key={s.subject} className="glass p-5">
                  <div className="flex items-center gap-2 text-xs uppercase tracking-wide text-muted-foreground">
                    <Award className="h-4 w-4 text-accent" /> Strength
                  </div>
                  <div className="mt-2 text-xl font-semibold">{s.subject}</div>
                  <div className="mt-1 text-sm text-muted-foreground">
                    Avg {s.average} • Trend {s.trend >= 0 ? "+" : ""}{s.trend}
                  </div>
                </div>
              ))}
            </section>

            <section className="glass p-6">
              <div className="prose-chat text-sm">
                <ReactMarkdown>{data.analysis}</ReactMarkdown>
              </div>
            </section>
          </>
        )}
      </main>
    </div>
  );
};

export default Interest;
