import { Navbar } from "@/components/Navbar";
import { Link } from "react-router-dom";
import { LayoutDashboard, Bell, BookOpen, MessageSquare } from "lucide-react";
import { useAuth } from "@/lib/auth";

const TeacherHome = () => {
  const { profile } = useAuth();
  const tiles = [
    { to: "/dashboard", icon: LayoutDashboard, title: "Class analytics", text: "Score timelines, subject breakdowns." },
    { to: "/notifications", icon: Bell, title: "Performance alerts", text: "See drops detected by AI." },
    { to: "/quiz", icon: BookOpen, title: "Build a quiz", text: "Generate MCQs to assign students." },
    { to: "/tutor", icon: MessageSquare, title: "AI Tutor", text: "Ask questions about any student." },
  ];
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl px-6 py-8 space-y-6">
        <header className="animate-fade-in">
          <h1 className="text-3xl font-semibold tracking-tight">Welcome, <span className="gradient-text">{profile?.name || "Teacher"}</span></h1>
          <p className="mt-1 text-sm text-muted-foreground">Monitor your class and intervene early.</p>
        </header>
        <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {tiles.map((t, i) => (
            <Link key={i} to={t.to} className="glass p-5 transition-transform hover:-translate-y-1 animate-fade-in">
              <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
                <t.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="mt-3 text-base font-semibold">{t.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{t.text}</p>
            </Link>
          ))}
        </section>
      </main>
    </div>
  );
};

export default TeacherHome;
