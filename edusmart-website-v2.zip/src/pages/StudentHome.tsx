import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { useAuth } from "@/lib/auth";
import { Link } from "react-router-dom";
import { MessageSquare, BookOpen, FileText, Sparkles, TrendingUp, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Attempt {
  id: string;
  topic: string;
  difficulty: string;
  total_questions: number;
  correct_answers: number;
  score_percent: number;
  kind: string;
  created_at: string;
}

const StudentHome = () => {
  const { profile, user } = useAuth();
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    (async () => {
      const { data } = await supabase
        .from("quiz_attempts")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(20);
      setAttempts((data as Attempt[]) ?? []);
      setLoading(false);
    })();
  }, [user]);

  const total = attempts.length;
  const avg = total ? attempts.reduce((a, b) => a + Number(b.score_percent), 0) / total : 0;
  const best = total ? Math.max(...attempts.map(a => Number(a.score_percent))) : 0;

  const tiles = [
    { to: "/tutor", icon: MessageSquare, title: "Ask the AI Tutor", text: "Personalized explanations and practice." },
    { to: "/quiz", icon: BookOpen, title: "Take a quiz", text: "AI-generated MCQs on any topic." },
    { to: "/notes", icon: FileText, title: "Generate notes", text: "Summarize a topic or paste text." },
    { to: "/interest", icon: Sparkles, title: "Interest analysis", text: "Discover what you're best at." },
  ];
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl px-6 py-8 space-y-6">
        <header className="animate-fade-in">
          <h1 className="text-3xl font-semibold tracking-tight">
            Hello, <span className="gradient-text">{profile?.name || "Student"}</span> 👋
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Your learning hub — pick what you want to do today.</p>
        </header>
        <section className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {tiles.map((t, i) => (
            <Link key={i} to={t.to} className="glass p-5 transition-transform hover:-translate-y-1 animate-fade-in">
              <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
                <t.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="mt-3 text-base font-semibold">{t.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{t.text}</p>
            </Link>
          ))}
        </section>

        <section className="glass p-6">
          <div className="flex items-center gap-3">
            <TrendingUp className="h-5 w-5 text-accent" />
            <h2 className="text-lg font-semibold">Your performance</h2>
          </div>

          {loading ? (
            <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading your attempts…
            </div>
          ) : total === 0 ? (
            <p className="mt-2 text-sm text-muted-foreground">
              No quiz attempts yet. Take a quiz to start tracking your performance!
            </p>
          ) : (
            <>
              <div className="mt-4 grid gap-4 sm:grid-cols-3">
                <Stat label="Quizzes taken" value={String(total)} />
                <Stat label="Average score" value={`${avg.toFixed(1)}%`} />
                <Stat label="Best score" value={`${best.toFixed(0)}%`} />
              </div>

              <div className="mt-5 overflow-hidden rounded-lg border border-border">
                <table className="w-full text-sm">
                  <thead className="bg-secondary/40 text-xs uppercase text-muted-foreground">
                    <tr>
                      <th className="px-4 py-2 text-left">Topic</th>
                      <th className="px-4 py-2 text-left">Difficulty</th>
                      <th className="px-4 py-2 text-left">Score</th>
                      <th className="px-4 py-2 text-left">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {attempts.slice(0, 10).map((a) => (
                      <tr key={a.id} className="border-t border-border">
                        <td className="px-4 py-2 font-medium">{a.topic}</td>
                        <td className="px-4 py-2 capitalize text-muted-foreground">{a.difficulty}</td>
                        <td className="px-4 py-2">
                          {a.correct_answers}/{a.total_questions}{" "}
                          <span className="text-muted-foreground">({Number(a.score_percent).toFixed(0)}%)</span>
                        </td>
                        <td className="px-4 py-2 text-muted-foreground">
                          {new Date(a.created_at).toLocaleDateString()}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}

          <Link to="/dashboard" className="btn-brand mt-4 inline-block">View full analytics</Link>
        </section>
      </main>
    </div>
  );
};

const Stat = ({ label, value }: { label: string; value: string }) => (
  <div className="rounded-lg border border-border bg-secondary/30 p-4">
    <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
    <div className="mt-1 text-2xl font-semibold gradient-text">{value}</div>
  </div>
);

export default StudentHome;
