import { Navbar } from "@/components/Navbar";
import { Link } from "react-router-dom";
import { LayoutDashboard, Bell, Sparkles } from "lucide-react";
import { useAuth } from "@/lib/auth";

const ParentHome = () => {
  const { profile } = useAuth();
  const tiles = [
    { to: "/dashboard", icon: LayoutDashboard, title: "Child's performance", text: "Trends across subjects." },
    { to: "/notifications", icon: Bell, title: "Alerts inbox", text: "Get notified when scores drop." },
    { to: "/interest", icon: Sparkles, title: "Strengths & interests", text: "AI suggestions for learning paths." },
  ];
  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl px-6 py-8 space-y-6">
        <header className="animate-fade-in">
          <h1 className="text-3xl font-semibold tracking-tight">Hi, <span className="gradient-text">{profile?.name || "Parent"}</span></h1>
          <p className="mt-1 text-sm text-muted-foreground">Stay informed about your child's progress.</p>
        </header>
        <section className="grid gap-4 md:grid-cols-3">
          {tiles.map((t, i) => (
            <Link key={i} to={t.to} className="glass p-5 transition-transform hover:-translate-y-1 animate-fade-in">
              <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
                <t.icon className="h-5 w-5 text-primary-foreground" />
              </div>
              <h3 className="mt-3 text-base font-semibold">{t.title}</h3>
              <p className="mt-1 text-xs text-muted-foreground">{t.text}</p>
            </Link>
          ))}
        </section>
      </main>
    </div>
  );
};

export default ParentHome;
