import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Navbar } from "@/components/Navbar";
import { StudentPicker } from "@/components/StudentPicker";
import { Student, Subject, ScoreRow } from "@/lib/types";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";
import { TrendingDown, TrendingUp, Award, AlertTriangle, Loader2 } from "lucide-react";
import { toast } from "sonner";

const COLORS = ["#7c6ef7", "#38d9f5", "#e77ef7", "#4ade80", "#fbbf24"];

const Dashboard = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [scores, setScores] = useState<ScoreRow[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);

  useEffect(() => {
    (async () => {
      const [{ data: st }, { data: sb }, { data: sc }] = await Promise.all([
        supabase.from("students").select("*").order("name"),
        supabase.from("subjects").select("*").order("name"),
        supabase.from("scores").select("*").order("test_date", { ascending: true }),
      ]);
      setStudents((st as Student[]) ?? []);
      setSubjects((sb as Subject[]) ?? []);
      setScores((sc as ScoreRow[]) ?? []);
      if (st && st.length) setSelectedId(st[0].id);
    })();
  }, []);

  const student = students.find((s) => s.id === selectedId);
  const studentScores = useMemo(
    () => scores.filter((r) => r.student_id === selectedId),
    [scores, selectedId],
  );

  // Build chart data: array of { date, [subjectName]: score }
  const chartData = useMemo(() => {
    const byDate = new Map<string, Record<string, number | string>>();
    for (const r of studentScores) {
      const d = r.test_date;
      const subj = subjects.find((x) => x.id === r.subject_id)?.name ?? "?";
      if (!byDate.has(d)) byDate.set(d, { date: d });
      byDate.get(d)![subj] = r.score;
    }
    return [...byDate.values()].sort((a, b) => String(a.date).localeCompare(String(b.date)));
  }, [studentScores, subjects]);

  // Compute subject averages and trend
  const summary = useMemo(() => {
    const out: { subject: string; avg: number; latest: number; trend: number }[] = [];
    for (const sub of subjects) {
      const arr = studentScores
        .filter((r) => r.subject_id === sub.id)
        .sort((a, b) => a.test_date.localeCompare(b.test_date));
      if (!arr.length) continue;
      const avg = arr.reduce((a, b) => a + Number(b.score), 0) / arr.length;
      const latest = Number(arr[arr.length - 1].score);
      const prev = arr.slice(-4, -1);
      const prevAvg = prev.length ? prev.reduce((a, b) => a + Number(b.score), 0) / prev.length : latest;
      out.push({ subject: sub.name, avg, latest, trend: latest - prevAvg });
    }
    return out.sort((a, b) => b.avg - a.avg);
  }, [studentScores, subjects]);

  const runCheck = async () => {
    setChecking(true);
    try {
      const { data, error } = await supabase.functions.invoke("check-performance", { body: {} });
      if (error) throw error;
      toast.success(`Performance scan complete — ${data?.created ?? 0} alerts created`);
    } catch (e) {
      toast.error("Failed to run performance check");
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl space-y-6 px-6 py-8">
        <section className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">
              Welcome to <span className="gradient-text">EduSmart</span>
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              AI-powered tutoring, performance alerts, and personalized interest analysis.
            </p>
          </div>
          <button onClick={runCheck} disabled={checking} className="btn-brand inline-flex items-center gap-2">
            {checking ? <Loader2 className="h-4 w-4 animate-spin" /> : <AlertTriangle className="h-4 w-4" />}
            Scan all students for drops
          </button>
        </section>

        <section className="glass p-5">
          <div className="mb-3 text-xs uppercase tracking-wide text-muted-foreground">Select a student</div>
          <StudentPicker students={students} selectedId={selectedId} onSelect={setSelectedId} />
        </section>

        {student && (
          <>
            <section className="grid gap-4 md:grid-cols-3">
              <StatCard
                label="Top subject"
                value={summary[0]?.subject ?? "—"}
                hint={summary[0] ? `${summary[0].avg.toFixed(1)} avg` : ""}
                icon={<Award className="h-4 w-4 text-accent" />}
              />
              <StatCard
                label="Latest trend"
                value={
                  summary.length
                    ? `${summary.reduce((a, b) => a + b.trend, 0) >= 0 ? "+" : ""}${(
                        summary.reduce((a, b) => a + b.trend, 0) / summary.length
                      ).toFixed(1)} pts`
                    : "—"
                }
                hint="Avg change vs prior tests"
                icon={
                  summary.reduce((a, b) => a + b.trend, 0) >= 0 ? (
                    <TrendingUp className="h-4 w-4 text-[hsl(var(--success))]" />
                  ) : (
                    <TrendingDown className="h-4 w-4 text-[hsl(var(--destructive))]" />
                  )
                }
              />
              <StatCard
                label="Subjects at risk"
                value={String(summary.filter((s) => s.trend <= -5).length)}
                hint="Drops of 5+ points"
                icon={<AlertTriangle className="h-4 w-4 text-[hsl(var(--warning))]" />}
              />
            </section>

            <section className="glass p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h2 className="text-lg font-semibold">Score timeline</h2>
                  <p className="text-xs text-muted-foreground">Weekly tests across subjects</p>
                </div>
              </div>
              <div className="h-72 w-full">
                <ResponsiveContainer>
                  <LineChart data={chartData} margin={{ top: 5, right: 10, left: -10, bottom: 0 }}>
                    <CartesianGrid stroke="hsl(var(--border))" strokeDasharray="3 3" />
                    <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <YAxis domain={[0, 100]} stroke="hsl(var(--muted-foreground))" fontSize={11} />
                    <Tooltip
                      contentStyle={{
                        background: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: 8,
                      }}
                    />
                    <Legend wrapperStyle={{ fontSize: 12 }} />
                    {subjects.map((sub, i) => (
                      <Line
                        key={sub.id}
                        type="monotone"
                        dataKey={sub.name}
                        stroke={COLORS[i % COLORS.length]}
                        strokeWidth={2}
                        dot={{ r: 2 }}
                      />
                    ))}
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </section>

            <section className="glass overflow-hidden">
              <div className="border-b border-border p-5">
                <h2 className="text-lg font-semibold">Subject breakdown</h2>
              </div>
              <table className="w-full text-sm">
                <thead className="bg-secondary/40 text-xs uppercase text-muted-foreground">
                  <tr>
                    <th className="px-5 py-3 text-left">Subject</th>
                    <th className="px-5 py-3 text-left">Average</th>
                    <th className="px-5 py-3 text-left">Latest</th>
                    <th className="px-5 py-3 text-left">Trend</th>
                  </tr>
                </thead>
                <tbody>
                  {summary.map((s) => (
                    <tr key={s.subject} className="border-t border-border">
                      <td className="px-5 py-3 font-medium">{s.subject}</td>
                      <td className="px-5 py-3">{s.avg.toFixed(1)}</td>
                      <td className="px-5 py-3">{s.latest.toFixed(1)}</td>
                      <td
                        className={`px-5 py-3 ${
                          s.trend >= 0
                            ? "text-[hsl(var(--success))]"
                            : "text-[hsl(var(--destructive))]"
                        }`}
                      >
                        {s.trend >= 0 ? "+" : ""}
                        {s.trend.toFixed(1)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>
          </>
        )}
      </main>
    </div>
  );
};

const StatCard = ({
  label, value, hint, icon,
}: { label: string; value: string; hint?: string; icon?: React.ReactNode }) => (
  <div className="glass p-5">
    <div className="flex items-center justify-between text-xs uppercase tracking-wide text-muted-foreground">
      <span>{label}</span>
      {icon}
    </div>
    <div className="mt-2 text-2xl font-semibold">{value}</div>
    {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
  </div>
);

export default Dashboard;
