import { useEffect, useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, Users, Shield } from "lucide-react";
import { toast } from "sonner";

interface ProfileRow { id: string; name: string; }
interface RoleRow { user_id: string; role: string; }
const ROLES = ["student", "teacher", "parent", "admin"] as const;

const Admin = () => {
  const [profiles, setProfiles] = useState<ProfileRow[]>([]);
  const [roles, setRoles] = useState<RoleRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const [{ data: p }, { data: r }] = await Promise.all([
      supabase.from("profiles").select("id, name").order("name"),
      supabase.from("user_roles").select("user_id, role"),
    ]);
    setProfiles((p as ProfileRow[]) ?? []);
    setRoles((r as RoleRow[]) ?? []);
    setLoading(false);
  };
  useEffect(() => { load(); }, []);

  const userRoles = (uid: string) => roles.filter((r) => r.user_id === uid).map((r) => r.role);

  const toggleRole = async (uid: string, role: string) => {
    const has = userRoles(uid).includes(role);
    if (has) {
      const { error } = await supabase.from("user_roles").delete().eq("user_id", uid).eq("role", role as any);
      if (error) return toast.error(error.message);
      toast.success(`Removed ${role}`);
    } else {
      const { error } = await supabase.from("user_roles").insert({ user_id: uid, role: role as any });
      if (error) return toast.error(error.message);
      toast.success(`Granted ${role}`);
    }
    load();
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-7xl px-6 py-8 space-y-6">
        <header className="flex items-center gap-3 animate-fade-in">
          <Shield className="h-6 w-6 text-primary" />
          <div>
            <h1 className="text-3xl font-semibold tracking-tight">Admin Panel</h1>
            <p className="text-sm text-muted-foreground">Manage users and assign roles.</p>
          </div>
        </header>

        <section className="glass overflow-hidden">
          <div className="border-b border-border p-5 flex items-center gap-2">
            <Users className="h-4 w-4 text-muted-foreground" />
            <h2 className="text-lg font-semibold">All users</h2>
            <span className="ml-auto text-xs text-muted-foreground">{profiles.length} accounts</span>
          </div>
          {loading ? (
            <div className="grid place-items-center p-10"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>
          ) : (
            <table className="w-full text-sm">
              <thead className="bg-secondary/40 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="px-5 py-3 text-left">Name</th>
                  <th className="px-5 py-3 text-left">Roles</th>
                </tr>
              </thead>
              <tbody>
                {profiles.map((p) => (
                  <tr key={p.id} className="border-t border-border">
                    <td className="px-5 py-3 font-medium">{p.name || <span className="text-muted-foreground italic">(no name)</span>}</td>
                    <td className="px-5 py-3">
                      <div className="flex flex-wrap gap-2">
                        {ROLES.map((r) => {
                          const active = userRoles(p.id).includes(r);
                          return (
                            <button key={r} onClick={() => toggleRole(p.id, r)}
                              className={`rounded-full border px-3 py-1 text-xs capitalize transition-colors ${
                                active ? "border-primary bg-primary/10 text-foreground" : "border-border text-muted-foreground hover:text-foreground"
                              }`}>{r}</button>
                          );
                        })}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </main>
    </div>
  );
};

export default Admin;
