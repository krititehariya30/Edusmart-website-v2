import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, roleHome } from "@/lib/auth";
import { Loader2, GraduationCap } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const schema = z.object({
  email: z.string().email().max(255),
  password: z.string().min(6).max(128),
});

const Login = () => {
  const nav = useNavigate();
  const { refresh } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse({ email, password });
    if (!parsed.success) { toast.error("Invalid email or password"); return; }
    setLoading(true);
    const { error, data } = await supabase.auth.signInWithPassword({ email: parsed.data.email, password: parsed.data.password });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    await refresh();
    const { data: r } = await supabase.from("user_roles").select("role").eq("user_id", data.user!.id).limit(1).maybeSingle();
    nav(roleHome((r?.role as any) ?? "student"), { replace: true });
  };

  return (
    <div className="grid min-h-screen place-items-center px-4">
      <div className="w-full max-w-md glass p-8 animate-scale-in">
        <Link to="/" className="flex items-center gap-2 mb-6">
          <div className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-base font-semibold gradient-text">EduSmart</span>
        </Link>
        <h1 className="text-2xl font-semibold">Welcome back</h1>
        <p className="mt-1 text-sm text-muted-foreground">Sign in to continue learning.</p>
        <form onSubmit={submit} className="mt-6 space-y-3">
          <input className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-2.5 text-sm outline-none focus:border-primary"
            type="email" placeholder="Email" value={email} onChange={(e)=>setEmail(e.target.value)} required />
          <input className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-2.5 text-sm outline-none focus:border-primary"
            type="password" placeholder="Password" value={password} onChange={(e)=>setPassword(e.target.value)} required />
          <button type="submit" disabled={loading} className="btn-brand w-full inline-flex items-center justify-center gap-2">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Sign in
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          New here? <Link to="/signup" className="text-primary underline-offset-4 hover:underline">Create an account</Link>
        </p>
      </div>
    </div>
  );
};

export default Login;
