import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { Loader2, Sparkles, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";

interface Q { q: string; options: string[]; answerIndex: number; explanation?: string }

const Quiz = () => {
  const { user } = useAuth();
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<"easy"|"medium"|"hard">("medium");
  const [count, setCount] = useState(5);
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<Q[]>([]);
  const [picked, setPicked] = useState<Record<number, number>>({});
  const [submitted, setSubmitted] = useState(false);
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    setSubmitted(true);
    if (!user) {
      toast.info("Sign in to save your performance");
      return;
    }
    const correct = questions.reduce((acc, q, i) => acc + (picked[i] === q.answerIndex ? 1 : 0), 0);
    const pct = questions.length ? (correct / questions.length) * 100 : 0;
    setSaving(true);
    const { error } = await supabase.from("quiz_attempts").insert({
      user_id: user.id,
      topic: topic.trim() || "Untitled",
      difficulty,
      total_questions: questions.length,
      correct_answers: correct,
      score_percent: Number(pct.toFixed(2)),
      kind: "quiz",
    });
    setSaving(false);
    if (error) toast.error("Could not save attempt");
    else toast.success(`Saved! Score ${correct}/${questions.length} (${pct.toFixed(0)}%)`);
  };

  const generate = async () => {
    if (!topic.trim()) return toast.error("Enter a topic");
    setLoading(true); setQuestions([]); setPicked({}); setSubmitted(false);
    try {
      const { data, error } = await supabase.functions.invoke("ai-quiz", {
        body: { topic: topic.trim(), difficulty, count },
      });
      if (error) throw error;
      const qs = (data?.questions ?? []) as Q[];
      if (!qs.length) throw new Error("No questions returned");
      setQuestions(qs);
    } catch (e: any) {
      toast.error(e?.message || "Failed to generate quiz");
    } finally { setLoading(false); }
  };

  const score = questions.reduce((acc, q, i) => acc + (picked[i] === q.answerIndex ? 1 : 0), 0);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-4xl px-6 py-8 space-y-6">
        <header className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold">AI Quiz Generator</h1>
            <p className="text-sm text-muted-foreground">Generate MCQs on any topic and test yourself.</p>
          </div>
        </header>

        <section className="glass p-5 grid gap-3 md:grid-cols-[1fr,150px,120px,auto]">
          <input className="rounded-lg border border-border bg-secondary/50 px-4 py-2.5 text-sm outline-none focus:border-primary"
            placeholder="Topic (e.g. Photosynthesis)" value={topic} onChange={(e)=>setTopic(e.target.value)} />
          <select className="rounded-lg border border-border bg-secondary/50 px-3 py-2.5 text-sm" value={difficulty} onChange={(e)=>setDifficulty(e.target.value as any)}>
            <option value="easy">Easy</option><option value="medium">Medium</option><option value="hard">Hard</option>
          </select>
          <input type="number" min={1} max={10} className="rounded-lg border border-border bg-secondary/50 px-3 py-2.5 text-sm"
            value={count} onChange={(e)=>setCount(Math.max(1, Math.min(10, Number(e.target.value)||5)))} />
          <button onClick={generate} disabled={loading} className="btn-brand inline-flex items-center justify-center gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            Generate
          </button>
        </section>

        {questions.length > 0 && (
          <section className="space-y-4 animate-fade-in">
            {questions.map((q, i) => (
              <div key={i} className="glass p-5">
                <p className="font-medium mb-3">{i+1}. {q.q}</p>
                <div className="grid gap-2">
                  {q.options.map((opt, j) => {
                    const selected = picked[i] === j;
                    const correct = submitted && j === q.answerIndex;
                    const wrong = submitted && selected && j !== q.answerIndex;
                    return (
                      <button key={j} onClick={() => !submitted && setPicked({ ...picked, [i]: j })}
                        className={`text-left rounded-lg border px-4 py-2 text-sm transition-colors ${
                          correct ? "border-[hsl(var(--success))] bg-[hsl(var(--success)/0.12)]"
                          : wrong ? "border-destructive bg-destructive/10"
                          : selected ? "border-primary bg-primary/10"
                          : "border-border bg-secondary/40 hover:bg-secondary"
                        }`}>
                        <span className="mr-2 text-muted-foreground">{String.fromCharCode(65+j)}.</span>{opt}
                        {correct && <CheckCircle2 className="float-right h-4 w-4 text-[hsl(var(--success))]" />}
                        {wrong && <XCircle className="float-right h-4 w-4 text-destructive" />}
                      </button>
                    );
                  })}
                </div>
                {submitted && q.explanation && (
                  <p className="mt-3 text-xs text-muted-foreground"><span className="text-foreground font-medium">Explanation: </span>{q.explanation}</p>
                )}
              </div>
            ))}
            <div className="flex items-center justify-between glass p-5">
              {submitted ? (
                <div className="text-lg">Score: <span className="gradient-text font-semibold">{score} / {questions.length}</span></div>
              ) : <div className="text-sm text-muted-foreground">{Object.keys(picked).length} / {questions.length} answered</div>}
              <button onClick={handleSubmit} disabled={submitted || saving} className="btn-brand inline-flex items-center gap-2">
                {saving && <Loader2 className="h-4 w-4 animate-spin" />}
                Submit answers
              </button>
            </div>
          </section>
        )}
      </main>
    </div>
  );
};

export default Quiz;
