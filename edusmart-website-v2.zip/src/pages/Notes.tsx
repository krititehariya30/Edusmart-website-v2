import { useState } from "react";
import { Navbar } from "@/components/Navbar";
import { supabase } from "@/integrations/supabase/client";
import ReactMarkdown from "react-markdown";
import { Loader2, FileText, Sparkles } from "lucide-react";
import { toast } from "sonner";

interface Result { summary: string; keyConcepts: string[]; flashcards: { front: string; back: string }[] }

const Notes = () => {
  const [text, setText] = useState("");
  const [topic, setTopic] = useState("");
  const [loading, setLoading] = useState(false);
  const [res, setRes] = useState<Result | null>(null);
  const [flipped, setFlipped] = useState<Record<number, boolean>>({});

  const generate = async () => {
    if (!text.trim() && !topic.trim()) return toast.error("Provide a topic or paste text");
    setLoading(true); setRes(null); setFlipped({});
    try {
      const { data, error } = await supabase.functions.invoke("ai-notes", {
        body: { text: text.trim(), topic: topic.trim() },
      });
      if (error) throw error;
      setRes(data as Result);
    } catch (e: any) {
      toast.error(e?.message || "Failed to generate notes");
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="mx-auto max-w-5xl px-6 py-8 space-y-6">
        <header className="flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
            <FileText className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h1 className="text-2xl font-semibold">AI Notes Generator</h1>
            <p className="text-sm text-muted-foreground">Generate summaries, key concepts and flashcards from a topic or text.</p>
          </div>
        </header>

        <section className="glass p-5 space-y-3">
          <input className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-2.5 text-sm outline-none focus:border-primary"
            placeholder="Topic (e.g. Newton's laws)" value={topic} onChange={(e)=>setTopic(e.target.value)} />
          <textarea className="w-full min-h-[160px] rounded-lg border border-border bg-secondary/50 px-4 py-3 text-sm outline-none focus:border-primary"
            placeholder="…or paste text to summarize" value={text} onChange={(e)=>setText(e.target.value)} />
          <button onClick={generate} disabled={loading} className="btn-brand inline-flex items-center gap-2">
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            Generate notes
          </button>
        </section>

        {res && (
          <section className="space-y-6 animate-fade-in">
            <div className="glass p-6">
              <h2 className="text-lg font-semibold mb-3">Summary</h2>
              <div className="prose-chat"><ReactMarkdown>{res.summary || ""}</ReactMarkdown></div>
            </div>
            {res.keyConcepts?.length > 0 && (
              <div className="glass p-6">
                <h2 className="text-lg font-semibold mb-3">Key concepts</h2>
                <div className="flex flex-wrap gap-2">
                  {res.keyConcepts.map((k, i) => (
                    <span key={i} className="rounded-full border border-primary/40 bg-primary/10 px-3 py-1 text-xs">{k}</span>
                  ))}
                </div>
              </div>
            )}
            {res.flashcards?.length > 0 && (
              <div className="glass p-6">
                <h2 className="text-lg font-semibold mb-3">Flashcards</h2>
                <div className="grid gap-3 md:grid-cols-2">
                  {res.flashcards.map((f, i) => (
                    <button key={i} onClick={() => setFlipped({ ...flipped, [i]: !flipped[i] })}
                      className="text-left rounded-xl border border-border bg-secondary/40 p-4 transition-colors hover:bg-secondary">
                      <div className="text-xs uppercase text-muted-foreground mb-1">{flipped[i] ? "Answer" : "Question"}</div>
                      <div className="text-sm">{flipped[i] ? f.back : f.front}</div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}
      </main>
    </div>
  );
};

export default Notes;
