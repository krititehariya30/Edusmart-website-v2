import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { roleHome, AppRole } from "@/lib/auth";
import { Loader2, GraduationCap } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";

const schema = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().email().max(255),
  password: z.string().min(6).max(128),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  parent_email: z.string().email().max(255).optional().or(z.literal("")),
  parent_phone: z.string().trim().max(40).optional().or(z.literal("")),
  teacher_email: z.string().email().max(255).optional().or(z.literal("")),
  teacher_phone: z.string().trim().max(40).optional().or(z.literal("")),
  role: z.enum(["student","teacher","parent","admin"]),
});

const Signup = () => {
  const nav = useNavigate();
  const [form, setForm] = useState({
    name: "", email: "", password: "", phone: "",
    parent_email: "", parent_phone: "", teacher_email: "", teacher_phone: "",
    role: "student" as AppRole,
  });
  const [loading, setLoading] = useState(false);
  const set = (k: string, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email: parsed.data.email,
      password: parsed.data.password,
      options: {
        emailRedirectTo: `${window.location.origin}/`,
        data: {
          name: parsed.data.name,
          phone: parsed.data.phone,
          role: parsed.data.role,
          parent_email: parsed.data.parent_email,
          parent_phone: parsed.data.parent_phone,
          teacher_email: parsed.data.teacher_email,
          teacher_phone: parsed.data.teacher_phone,
        },
      },
    });
    setLoading(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Account created!");
    nav(roleHome(parsed.data.role), { replace: true });
  };

  const isStudent = form.role === "student";

  return (
    <div className="grid min-h-screen place-items-center px-4 py-8">
      <div className="w-full max-w-lg glass p-8 animate-scale-in">
        <Link to="/" className="flex items-center gap-2 mb-6">
          <div className="grid h-9 w-9 place-items-center rounded-xl" style={{ background: "var(--gradient-brand)" }}>
            <GraduationCap className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-base font-semibold gradient-text">EduSmart</span>
        </Link>
        <h1 className="text-2xl font-semibold">Create your account</h1>
        <p className="mt-1 text-sm text-muted-foreground">Pick your role to get a tailored dashboard.</p>

        <form onSubmit={submit} className="mt-6 grid gap-3">
          <div className="grid grid-cols-4 gap-2">
            {(["student","teacher","parent","admin"] as AppRole[]).map((r) => (
              <button type="button" key={r}
                onClick={() => set("role", r)}
                className={`rounded-lg border px-2 py-2 text-xs capitalize transition-colors ${
                  form.role === r ? "border-primary bg-primary/10 text-foreground" : "border-border bg-secondary/40 text-muted-foreground"
                }`}>{r}</button>
            ))}
          </div>
          <Field placeholder="Full name" value={form.name} onChange={(v)=>set("name",v)} />
          <Field placeholder="Email" type="email" value={form.email} onChange={(v)=>set("email",v)} />
          <Field placeholder="Password (min 6)" type="password" value={form.password} onChange={(v)=>set("password",v)} />
          <Field placeholder="Phone (optional)" value={form.phone} onChange={(v)=>set("phone",v)} />
          {isStudent && (
            <div className="rounded-lg border border-border bg-secondary/30 p-3 space-y-3">
              <p className="text-xs uppercase text-muted-foreground tracking-wide">Parent & teacher contact</p>
              <Field placeholder="Parent email" type="email" value={form.parent_email} onChange={(v)=>set("parent_email",v)} />
              <Field placeholder="Parent phone" value={form.parent_phone} onChange={(v)=>set("parent_phone",v)} />
              <Field placeholder="Teacher email" type="email" value={form.teacher_email} onChange={(v)=>set("teacher_email",v)} />
              <Field placeholder="Teacher phone" value={form.teacher_phone} onChange={(v)=>set("teacher_phone",v)} />
            </div>
          )}
          <button type="submit" disabled={loading} className="btn-brand w-full inline-flex items-center justify-center gap-2">
            {loading && <Loader2 className="h-4 w-4 animate-spin" />} Create account
          </button>
        </form>
        <p className="mt-4 text-center text-sm text-muted-foreground">
          Already have an account? <Link to="/login" className="text-primary hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
};

const Field = ({ placeholder, value, onChange, type = "text" }:
  { placeholder: string; value: string; onChange: (v: string) => void; type?: string }) => (
  <input className="w-full rounded-lg border border-border bg-secondary/50 px-4 py-2.5 text-sm outline-none focus:border-primary"
    type={type} placeholder={placeholder} value={value} onChange={(e)=>onChange(e.target.value)} />
);

export default Signup;
